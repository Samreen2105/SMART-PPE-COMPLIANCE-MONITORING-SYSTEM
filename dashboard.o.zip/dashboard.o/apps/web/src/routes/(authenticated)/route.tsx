import Header from '@/components/Header'
import { createFileRoute, Outlet } from '@tanstack/react-router'

export const Route = createFileRoute('/(authenticated)')({
  component: RouteComponent,
})

function RouteComponent() {
  return <section className='grid grid-rows-[auto_1fr] max-h-screen p-2 gap-1'>
      <Header />
      <Outlet/>
  </section>
}
