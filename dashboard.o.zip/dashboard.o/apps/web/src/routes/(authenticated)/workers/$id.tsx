import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { GlowingLineChart } from "@/components/ui/glowing-line";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { faker } from "@faker-js/faker";
import { createFileRoute } from "@tanstack/react-router";
import { nanoid } from "nanoid";
import { Suspense } from "react";

export const Route = createFileRoute("/(authenticated)/workers/$id")({
  component: RouteComponent,
});

function RouteComponent() {
  const { id } = Route.useParams();
  const cardData = {
    image_url: faker.image.personPortrait({ sex: "male", size: 256 }),
    name: faker.person.fullName({ sex: "male" }),
    id: nanoid(),
  };

  const statsCard: Array<{
    title: string;
    description: number | string;
    className?: string;
    // icon: React.ForwardRefExoticComponent<
    //   Omit<LucideProps, "ref"> & React.RefAttributes<SVGSVGElement>
    // >;
  }> = [
    {
      title: "Inside Since",
      description: new Intl.DateTimeFormat("en-IN", {
        hour: "2-digit",
        hourCycle: "h12",
        minute: "2-digit",
        second: "2-digit",
      }).format(faker.date.anytime()),

      // className: "from-rose-950 via-rose-700 to-rose-500",
    },

    {
      title: "Violations",
      description: faker.number.int({ min: 0, max: 365 }),

      // className: "from-stone-950 via-stone-700 to-stone-500",
    },

    {
      title: "Compliance Streak",
      description: faker.number.int({ min: 0, max: 365 }),

      // className: "from-stone-950 via-stone-700 to-stone-500",
    },
    {
      title: "Compliance Rate",
      description: `${faker.number.int({ min: 0, max: 100 })}%`,

      className: "from-indigo-950 via-indigo-600 to-indigo-400",
    },
    {
      title: "Violation Rate",
      description: faker.number.int({ min: 0, max: 100 }) + "%",

      className: "from-rose-950 via-rose-700 to-rose-500",
    },

    {
      title: "Total entries",
      description: faker.number.int({ min: 0, max: 360 }),

      className: "from-stone-950 via-stone-700 to-stone-500",
    },
  ];

  return (
    <section className="grid gap-3 grid-rows-[auto_1fr] h-185 grid-cols-5 p-4">
      <Suspense fallback={<Skeleton />}>
        <Card
          className={cn(
            " bg-linear-to-br to-[150%] from-blue-800 via-blue-700 to-blue-300 col-span-2",
          )}
        >
          <CardContent className="rounded-none flex gap-y-1 flex-col relative p-4">
            <CardTitle className="text-foreground/80 text-sm font-light mb-2">
              {/* <HardHat absoluteStrokeWidth strokeWidth={1} /> */}
              worker Info
            </CardTitle>
            <section className="flex items-start gap-3">
              <Avatar className="aspect-square size-32">
                <AvatarImage
                  className="rounded-lg"
                  src={cardData?.image_url}
                  alt={cardData?.name}
                />
                <AvatarFallback className="rounded">
                  {cardData?.name[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex flex-col h-full">
                <p>
                  <span className="text-foreground/60">Name:</span>{" "}
                  {cardData?.name}
                </p>
                <p>
                  <span className="text-foreground/60">Role:</span>{" "}
                  {faker.helpers.arrayElement(["miner", "admin", "supervisor"])}
                </p>
                <p>
                  <span className="text-foreground/60">Joined:</span>{" "}
                  {new Intl.DateTimeFormat("en-IN", {
                    day: "numeric",
                    year: "numeric",
                    month: "2-digit",
                  }).format(faker.date.anytime())}
                </p>

                {/* <p>
                <span className="text-foreground/60">Total Entries:</span>{" "}
                {faker.number.int({ min: 10, max: 365 })}
              </p>
              <p>
                <span className="text-foreground/60">Total Violations:</span>{" "}
                {faker.number.int({ min: 10, max: 365 })}
              </p> */}
                <p>
                  <span className="text-foreground/60">ID:</span> {cardData?.id}
                </p>
                <p className="h-full flex flex-col-reverse pb-3">
                  <p className="bg-foreground/80 h-1/3" />
                </p>
              </div>
            </section>
          </CardContent>
        </Card>
      </Suspense>
      <Suspense>
        <section className="grid grid-cols-3 grid-rows-2 col-span-3 gap-3">
          {statsCard.map((item) => {
            return (
              <Card
                key={nanoid()}
                className={cn(" bg-linear-to-br to-[150%] p-0", item.className)}
              >
                <CardContent className=" flex flex-col items-start p-3 gap-1 h-fit">
                  <CardTitle className="text-foreground/80 text-sm font-light">
                    {item.title}
                  </CardTitle>
                  <CardDescription className="text-3xl font-bold text-foreground w-full">
                    {item.description}
                  </CardDescription>
                </CardContent>
              </Card>
            );
          })}
        </section>
      </Suspense>

      <Suspense>
        <Card className="col-span-full">
          <CardHeader>
            <CardTitle>Record of Compliance & Violations</CardTitle>
          </CardHeader>
          <CardContent>
            <GlowingLineChart className="h-100" />
          </CardContent>
        </Card>
      </Suspense>
    </section>
  );
}
