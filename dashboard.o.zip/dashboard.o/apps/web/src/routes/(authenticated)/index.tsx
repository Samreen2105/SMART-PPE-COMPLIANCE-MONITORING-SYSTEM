import { nanoid } from "nanoid";
import {
  Card,
  CardContent,
  CardDescription,
  CardTitle,
} from "@/components/ui/card";
import { createFileRoute } from "@tanstack/react-router";
import {
  TrendingUpIcon,
  UserRoundCheckIcon,
  UserRoundXIcon,
  UsersRoundIcon,
  type LucideProps,
} from "lucide-react";
import { cn } from "@/lib/utils";
import DataGridDemo from "@/components/data-grid/sticky-header";
export const Route = createFileRoute("/(authenticated)/")({
  component: RouteComponent,
});

function RouteComponent() {
  const data: Array<{
    title: string;
    description: string;
    className?: string;
    icon: React.ForwardRefExoticComponent<
      Omit<LucideProps, "ref"> & React.RefAttributes<SVGSVGElement>
    >;
  }> = [
    {
      title: "Workers inside mine",
      description: "50",
      icon: UserRoundCheckIcon,
      className: "from-blue-950 via-blue-600 to-blue-400",
    },
    {
      title: "Compliance Rate",
      description: "94.7%",
      icon: TrendingUpIcon,
      className: "from-indigo-950 via-indigo-600 to-indigo-400",
    },
    {
      title: "Violations today",
      description: "10",
      icon: UserRoundXIcon,
      className: "from-rose-950 via-rose-700 to-rose-500",
    },

    {
      title: "Total workers",
      description: "100",
      icon: UsersRoundIcon,
      className: "from-stone-950 via-stone-700 to-stone-500",
    },
  ];
  return (
    <section className="grid grid-flow-row grid-cols-4 p-3 rounded-md gap-3 gap-y-10 overflow-y-scroll grid-rows-[auto_1fr]">
      {data.map((item) => {
        return (
          <Card
            key={nanoid()}
            className={cn(" bg-linear-to-br to-[150%] ", item.className)}
          >
            <CardContent className="rounded-none flex gap-y-1 flex-col relative py-2">
              <CardTitle className="text-foreground/80 text-base">
                {item.title}
              </CardTitle>
              <CardDescription className="text-5xl font-bold text-foreground flex items-center justify-between">
                {item.description}
                {<item.icon className=" size-12" />}
              </CardDescription>
            </CardContent>
          </Card>
        );
      })}

      {/* <DataGridDemo /> */}
    </section>
  );
}
