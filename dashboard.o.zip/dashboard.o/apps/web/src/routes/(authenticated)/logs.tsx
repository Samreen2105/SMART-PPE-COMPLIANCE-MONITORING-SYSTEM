// import { Button } from "@/components/ui/base-button";
// import { useQueryClient } from "@tanstack/react-query";
// import { createFileRoute } from "@tanstack/react-router";
// import { nanoid } from "nanoid";
// import React, { useState } from "react";

// export const Route = createFileRoute("/(authenticated)/logs")({
//   component: RouteComponent,
// });

// function RouteComponent() {
//   const [messages, setMessages] = useState<string[]>([]);

//   React.useEffect(() => {
//     const socket = new WebSocket("ws://localhost:3000/ws");

//     socket.onopen = (event) => {
//       console.log("WebSocket client opened", event);
//     };

//     socket.onmessage = (event) => {
//       try {
//         const data: unknown = JSON.parse(event.data.toString());
//         setMessages((prev) => [...prev, data?.message]);
//       } catch (_) {
//         console.log("Message from server:", event.data);
//       }
//     };
//     socket.onclose = (event) => {
//       console.log("WebSocket client closed", event);
//     };

//     return () => {
//       socket.close();
//     };
//   }, []);
//   return (
//     <div>
//       Hello "/(authenticated)/logs"!
//       {/* <Button
//         onClick={() => {
//           if (socket) {
//             socket.send(JSON.stringify({ name: "web", msg: "workers" }));
//           }
//         }}
//       >
//         Send Msg
//       </Button> */}
//       {messages.map((item) => {
//         return <p key={nanoid()}> {item}</p>;
//       })}
//     </div>
//   );
// }
