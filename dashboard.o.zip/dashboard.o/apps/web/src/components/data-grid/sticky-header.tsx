import { useMemo, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { DataGrid, DataGridContainer } from "@/components/ui/data-grid";
import { DataGridTable } from "@/components/ui/data-grid-table";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import {
  type ColumnDef,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Link } from "@tanstack/react-router";
export default function DataGridDemo() {
  const [sorting, setSorting] = useState<SortingState>([
    { id: "name", desc: true },
  ]);

  const columns = useMemo<ColumnDef<IData>[]>(
    () => [
      {
        accessorKey: "timestamp",
        id: "timestamp",
        header: "Timestamp",
        cell: ({ row }) => {
          return (
            <p>
              {new Intl.DateTimeFormat("en-IN", {
                second: "2-digit",
                minute: "2-digit",
                hour: "2-digit",
                day: "numeric",
                month: "numeric",
                timeZoneName: "short",
              }).format(row.original.timestamp)}
            </p>
          );
        },
        enableSorting: false,
        enableHiding: false,
      },
      {
        accessorKey: "name",
        id: "name",
        header: "Name",
        cell: ({ row }) => {
          return (
            <div className="flex items-center gap-3">
              <Avatar className="size-8">
                <AvatarImage
                  src={row.original.image_url}
                  alt={row.original.name}
                />
                <AvatarFallback>
                  {row.original.name[0].toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-px">
                <Link
                  to={`/workers/$id`}
                  params={{ id: row.original.id }}
                  className="font-medium text-foreground/60"
                >
                  {row.original.name}
                </Link>
              </div>
            </div>
          );
        },
        size: 225,
        enableSorting: true,
        enableHiding: false,
      },
      {
        accessorKey: "status",
        id: "status",
        header: "Status",
        cell: ({ row }) => {
          const status = row.original.status;
          return (
            <Badge
              variant={
                status === "ENTER"
                  ? "primary"
                  : status === "COMPLIANT"
                    ? "success"
                    : "destructive"
              }
              appearance="light"
              className={cn(status === "ENTER" && "text-foreground")}
            >
              {status}
            </Badge>
          );
        },
        size: 100,
      },
    ],
    [],
  );

  const table = useReactTable({
    columns,
    data: logData,
    getRowId: (row: ) => row.id,
    state: {
      sorting,
    },

    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <Card className="col-span-4">
      <CardContent className=" p-0 ">
        <CardHeader className="">
          <CardTitle className="p-5 px-0 animate-blink direction-reverse">
            Live Logs
          </CardTitle>
        </CardHeader>
        <DataGrid
          table={table}
          recordCount={workersBucket.workerData.workers?.length || 0}
          tableLayout={{ headerSticky: true }}
        >
          <div className="space-y-2.5">
            <DataGridContainer className="border-0">
              <ScrollArea className="max-h-128">
                <DataGridTable />
                <ScrollBar orientation="horizontal" />
              </ScrollArea>
            </DataGridContainer>
          </div>
        </DataGrid>
      </CardContent>
    </Card>
  );
}
