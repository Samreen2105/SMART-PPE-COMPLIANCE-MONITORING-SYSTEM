"use client";

import { CartesianGrid, Line, LineChart, XAxis, YAxis } from "recharts";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { cn } from "@/lib/utils";

const chartData = [
  { month: "January", compliance: 186, violations: 87 },
  { month: "February", compliance: 305, violations: 163 },
  { month: "March", compliance: 237, violations: 142 },
  { month: "April", compliance: 73, violations: 195 },
  { month: "May", compliance: 209, violations: 118 },
  { month: "June", compliance: 214, violations: 231 },
];

const chartConfig = {
  compliance: {
    label: "Compliance",
    color: "var(--color-blue-500)",
  },
  violations: {
    label: "Violations",
    color: "var(--chart-5)",
  },
} satisfies ChartConfig;

export function GlowingLineChart({ className }: { className: string }) {
  return (
    <ChartContainer className={cn("w-full", className)} config={chartConfig}>
      <LineChart
        accessibilityLayer
        data={chartData}
        margin={{
          left: 12,
          right: 12,
        }}
      >
        <CartesianGrid vertical={false} />
        <XAxis
          dataKey="month"
          tickLine={false}
          axisLine={false}
          tickMargin={8}
          tickFormatter={(value) => value.slice(0, 3)}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tickMargin={8}
          // tickFormatter={(value) => value.slice(0, 3)}
        />
        <ChartTooltip
          cursor={true}
          content={<ChartTooltipContent hideLabel />}
        />
        <Line
          dataKey="compliance"
          type="bump"
          stroke="var(--color-blue-500)"
          dot={false}
          strokeWidth={2}
          filter="url(#rainbow-line-glow)"
        />
        <Line
          dataKey="violations"
          type="bump"
          stroke="var(--chart-5)"
          dot={false}
          strokeWidth={2}
          filter="url(#rainbow-line-glow)"
        />
        <defs>
          <filter
            id="rainbow-line-glow"
            x="-20%"
            y="-20%"
            width="140%"
            height="140%"
          >
            <feGaussianBlur stdDeviation="10" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>
      </LineChart>
    </ChartContainer>
  );
}
