import { Button } from '@/components/ui/base-button';

export default function Component() {
  return <Button>Button</Button>;
}
