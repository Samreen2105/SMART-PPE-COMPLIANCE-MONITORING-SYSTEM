import { Link } from '@tanstack/react-router'

import {  Button, buttonVariants } from './ui/base-button'
import { Circle, User2Icon } from 'lucide-react'
import { cn } from '@/lib/utils'


export default function Header() {

  return (

      <header className="p-2 flex items-center rounded-md">
        {/* <Button size={"icon"} variant={"dim"}>

        <Menu size={24} />
        </Button> */}

  <nav className='flex items-center justify-between w-full'>
        <h1 className="ml-2 text-2xl ">
          <Link to="/" className='font-mono uppercase font-bold'>
          <span>quantra</span>
          <span className='text-blue-500'>X</span>
          </Link>
        </h1>
        <div className="flex items-center justify-center gap-2">
          <Link className={cn(buttonVariants({"variant":"dashed"}),"uppercase font-mono")} to='/live-camera'>
            <Circle className='size-2 fill-red-600 opacity-100 stroke-0 animate-blink'/>
            Live Camera
          </Link>
          <Button variant={"dashed"} className='bg-muted'>
            <User2Icon className='text-white'/>
            Admin
          </Button>

        </div>
  </nav>
      </header>
    
  )
}
